console.log('Hello World!');
var myName = ravi;
var = vir
